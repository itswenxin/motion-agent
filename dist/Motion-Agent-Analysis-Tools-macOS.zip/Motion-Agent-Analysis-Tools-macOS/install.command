#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

./install-macos.sh

echo
echo "Installation finished. You can close this window."
read -r -p "Press Return to close..." _
